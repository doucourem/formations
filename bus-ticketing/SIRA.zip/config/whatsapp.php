
<?php
return [
  'templates' => [
      'ticket_sent' => [
          'body' => "Bonjour {{NAME}} ! Votre billet {{REF}} pour {{ROUTE}} (départ {{TIME}}) est prêt. Voir le fichier joint."
      ],
      // Ajoute d'autres templates ici
  ],
];